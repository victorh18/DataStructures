using System;

namespace DataStructures{
    public static class LinkedListHandler<T>{
        public static void Add(Node<T> lol){
            
        }
    }
}